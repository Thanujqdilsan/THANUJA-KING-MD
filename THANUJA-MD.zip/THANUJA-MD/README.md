# THANUJA-MD Bot
This is a WhatsApp MD Bot like PRABATH-MD.