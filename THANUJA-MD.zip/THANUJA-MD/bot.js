// Main bot file
console.log('THANUJA-MD Bot Started');